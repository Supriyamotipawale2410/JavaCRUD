package com.demo.interfaces;

public interface I5 {
  void I51();
  void i52();
}
